package com.tchaso.tchaso.enumeration;

public enum Etat {
    actif , inactif
}

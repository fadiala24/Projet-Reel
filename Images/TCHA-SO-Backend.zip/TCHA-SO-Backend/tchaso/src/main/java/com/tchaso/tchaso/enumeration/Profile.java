package com.tchaso.tchaso.enumeration;

public enum Profile {

    super_admin,
    admin

}

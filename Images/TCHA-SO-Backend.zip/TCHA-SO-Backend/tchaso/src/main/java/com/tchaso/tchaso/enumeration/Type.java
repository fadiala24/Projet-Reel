package com.tchaso.tchaso.enumeration;

public enum Type {
    travailleur,
    client
}

package com.tchaso.tchaso.utils;

public interface Constant {

     String APP_ROOT = "tchaso/v1";

}

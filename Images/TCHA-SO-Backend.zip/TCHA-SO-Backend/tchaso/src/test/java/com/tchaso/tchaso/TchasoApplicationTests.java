package com.tchaso.tchaso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TchasoApplicationTests {

	@Test
	void contextLoads() {
	}

}
